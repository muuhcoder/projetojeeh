import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { About } from './components/About';
import { Services } from './components/Services';
import { Gallery } from './components/Gallery';
import { ContactLocation } from './components/ContactLocation';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';

export default function App() {
  const handleScrollTo = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const navOffset = 70;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - navOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth',
      });
    }
  };

  return (
    <div className="min-h-screen bg-[#080D1A] text-[#F8FAFC] selection:bg-[#E31837] selection:text-white flex flex-col font-sans">
      {/* 3-Zone Clean Header */}
      <Navbar onNavigate={handleScrollTo} />

      {/* Main Content Sections */}
      <main className="flex-grow">
        {/* 1. Impeccable First Screen Hero */}
        <Hero onScrollTo={handleScrollTo} />

        {/* 2. Tradição & Trégua (Sobre Nós) */}
        <About />

        {/* 3. Serviços & Valores Claros */}
        <Services />

        {/* 4. Galeria Visual & Acabamento */}
        <Gallery />

        {/* 5. Como Chegar & Atendimento por Ordem de Chegada */}
        <ContactLocation />
      </main>

      {/* Clean Editorial Footer */}
      <Footer onScrollTo={handleScrollTo} />

      {/* Floating WhatsApp Quick Inquiries */}
      <FloatingWhatsApp />
    </div>
  );
}
