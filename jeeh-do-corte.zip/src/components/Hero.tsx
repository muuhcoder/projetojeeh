import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Navigation, MessageSquare, Clock, ArrowDown } from 'lucide-react';

interface HeroProps {
  onScrollTo: (id: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollTo }) => {
  const heroImage = '/src/assets/images/hero_barber_craft_1793127382221.jpg';
  const mapsUrl = 'https://www.google.com/maps/search/?api=1&query=Av.+Jo%C3%A3o+Selvirio+de+Souza%2C+1522%2C+Selv%C3%ADria+-+MS';
  const whatsappUrl = 'https://wa.me/5567981160947?text=Ol%C3%A1%21%20Gostaria%20de%20saber%20se%20a%20barbearia%20est%C3%A1%20atendendo%20agora.';

  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden bg-[#080D1A]">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-[#E31837]/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-[#0F172A] rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Massive Confident Typography & Direct Action */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col items-start z-10"
          >
            {/* Unboxed Metadata Header (No static pill sandwich) */}
            <div className="flex items-center gap-3 text-xs md:text-sm font-semibold tracking-widest uppercase text-slate-400 mb-6">
              <span className="text-[#E31837]">Barbearia Autêntica</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Selvíria — MS</span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-[#E31837]" />
                Ordem de Chegada
              </span>
            </div>

            {/* Main Headline (Slogan: Max 8 words, bold, responsive clamp) */}
            <h1 className="font-display-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight text-white leading-[1.08] mb-6 [text-wrap:balance]">
              Precisão na lâmina. <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-slate-400">
                Atitude
              </span>{' '}
              no corte.
            </h1>

            {/* Single concise supporting statement */}
            <p className="text-base sm:text-lg text-slate-300 font-light leading-relaxed max-w-xl mb-8">
              A elegância do corte clássico e o alinhamento contemporâneo em Selvíria. Sem complicação de agendamento: puxe a cadeira, tome um café e saia transformado.
            </p>

            {/* Notice regarding first-come first-served queue */}
            <div className="w-full max-w-xl p-4 mb-8 rounded bg-[#10192C] border border-[#1E2D4A] flex items-start gap-3.5">
              <div className="mt-0.5 p-1.5 bg-[#E31837]/10 text-[#E31837] rounded shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div className="text-xs sm:text-sm text-slate-300 leading-snug">
                <span className="font-semibold text-white block mb-0.5">Atendimento sem hora marcada</span>
                Trabalhamos exclusivamente por ordem de chegada. Chegue com tranquilidade, relaxe no ambiente climatizado e seja atendido com rigor técnico.
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2.5 px-7 py-3.5 text-xs sm:text-sm font-bold tracking-wider uppercase text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-all duration-200 hover:shadow-xl hover:shadow-[#E31837]/25 text-center whitespace-nowrap"
              >
                <Navigation className="w-4 h-4" />
                <span>Como Chegar Agora</span>
              </a>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2.5 px-6 py-3.5 text-xs sm:text-sm font-semibold tracking-wider uppercase text-slate-200 hover:text-white bg-[#152238] hover:bg-[#1E2D4A] border border-[#1E2D4A] rounded transition-all duration-200 text-center whitespace-nowrap"
              >
                <MessageSquare className="w-4 h-4 text-[#E31837]" />
                <span>Tirar Dúvidas</span>
              </a>
            </div>

            {/* Quick Micro-data */}
            <div className="mt-10 pt-6 border-t border-[#1E2D4A]/50 flex items-center gap-6 text-xs text-slate-400">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#E31837]" />
                Av. João Selvirio de Souza, 1522
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Selvíria - MS</span>
            </div>
          </motion.div>

          {/* Right Column: Hero Visual Asset (Cinematic, High contrast) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative"
          >
            <div className="relative mx-auto max-w-lg lg:max-w-none">
              {/* Decorative accent geometry */}
              <div className="absolute -inset-1.5 bg-gradient-to-tr from-[#E31837]/30 to-[#0F172A] rounded-xl blur-lg opacity-70" />

              {/* Main Image Frame */}
              <div className="relative rounded-lg overflow-hidden border border-[#1E2D4A] shadow-2xl bg-[#080D1A]">
                <img
                  src={heroImage}
                  alt="Barbeiro profissional executando corte degradê na Jeeh do Corte"
                  referrerPolicy="no-referrer"
                  className="w-full h-[420px] sm:h-[480px] lg:h-[540px] object-cover object-center filter contrast-105"
                  loading="eager"
                />

                {/* Subtle vignette overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#080D1A] via-transparent to-black/20" />

                {/* Floating signature badge */}
                <div className="absolute bottom-5 left-5 right-5 p-4 rounded bg-[#080D1A]/90 backdrop-blur-md border border-[#1E2D4A] flex items-center justify-between">
                  <div>
                    <span className="text-[10px] uppercase tracking-widest text-[#E31837] font-bold block">
                      Espaço & Autenticidade
                    </span>
                    <span className="text-sm font-semibold text-white">
                      Jeeh do Corte Barber Club
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">Selvíria · MS</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Scroll invitation */}
        <div className="mt-14 flex justify-center">
          <button
            onClick={() => onScrollTo('sobre')}
            aria-label="Rolar para a seção sobre nós"
            className="group flex flex-col items-center gap-2 text-xs uppercase tracking-widest text-slate-500 hover:text-white transition-colors"
          >
            <span>Conheça a Barbearia</span>
            <ArrowDown className="w-4 h-4 text-[#E31837] animate-bounce" />
          </button>
        </div>
      </div>
    </section>
  );
};
