import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Check, Navigation, MessageSquare, Clock, Sparkles } from 'lucide-react';

export const Services: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'hair_beard' | 'color'>('all');

  const services = [
    {
      id: 'corte',
      title: 'Corte de Cabelo',
      category: 'hair_beard',
      price: 'R$ 30',
      duration: '35 min',
      description: 'Degradê na régua, fade americano, social clássico, militar ou tesoura com acabamento limpo na navalha.',
      image: '/src/assets/images/barber_service_cut_1793127382457.jpg',
      includes: ['Pezinho alinhado na lâmina', 'Pomada modeladora', 'Acabamento limpo e preciso'],
      badge: 'Tradicional',
    },
    {
      id: 'cabelo_barba',
      title: 'Cabelo e Barba',
      category: 'hair_beard',
      price: 'R$ 50',
      duration: '55 min',
      description: 'A combinação completa: corte com fade ou tesoura + desenho e aparo impecável da barba na navalha.',
      image: '/src/assets/images/hero_barber_craft_1793127382221.jpg',
      includes: ['Corte completo à sua escolha', 'Barba alinhada na lâmina', 'Pós-barba e finalização'],
      badge: 'Melhor Custo-Benefício',
    },
    {
      id: 'barba',
      title: 'Só Barba',
      category: 'hair_beard',
      price: 'R$ 25',
      duration: '25 min',
      description: 'Alinhamento do desenho, redução de volume e contorno detalhado com navalhete descartável.',
      image: '/src/assets/images/barber_service_beard_1793127382871.jpg',
      includes: ['Contorno de bochecha e pescoço', 'Lâmina descartável esterilizada', 'Loção pós-barba refrescante'],
      badge: 'Alinhamento',
    },
    {
      id: 'luzes',
      title: 'Luzes / Reflexo',
      category: 'color',
      price: 'A partir de R$ 80',
      duration: '1h 30 min',
      description: 'Mechas puxadas na touca técnica de silicone, clareamento uniforme e matização no tom platinado ou perolado.',
      image: '/src/assets/images/barber_platinado_nevou_1793127871915.jpg',
      includes: ['Puxado preciso na touca', 'Clareamento uniforme dos fios', 'Matização de alto brilho'],
      badge: 'Destaque',
    },
    {
      id: 'platinar',
      title: 'Platinar / Nevou',
      category: 'color',
      price: 'A partir de R$ 100',
      duration: '2h',
      description: 'Descoloração global completa e segura para atingir o platinado branco/gelo autêntico com proteção capilar.',
      image: '/src/assets/images/barber_platinado_nevou_1793127871915.jpg',
      includes: ['Descoloração global segura', 'Matização tom gelo/branco puro', 'Tratamento pós-química'],
      badge: 'Tendência',
    },
    {
      id: 'sobrancelha',
      title: 'Sobrancelha & Acabamento',
      category: 'hair_beard',
      price: 'R$ 10',
      duration: '15 min',
      description: 'Alinhamento rápido dos contornos e sobrancelha na lâmina para valorizar o olhar e o corte.',
      image: '/src/assets/images/barber_fade_profile_1793127397233.jpg',
      includes: ['Desenho natural sem falhas', 'Lâmina descartável nova', 'Acabamento express'],
      badge: 'Express',
    },
  ];

  const filteredServices = activeCategory === 'all'
    ? services
    : services.filter((s) => s.category === activeCategory);

  const mapsUrl = 'https://www.google.com/maps/search/?api=1&query=Av.+Jo%C3%A3o+Selvirio+de+Souza%2C+1522%2C+Selv%C3%ADria+-+MS';
  const whatsappUrl = 'https://wa.me/5567981160947?text=Ol%C3%A1%21%20Gostaria%20de%20tirar%20uma%20d%C3%BAvida%20sobre%20os%20servi%C3%A7os%20da%20Jeeh%20do%20Corte.';

  return (
    <section id="servicos" className="py-28 md:py-36 bg-[#080D1A] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16">
          <div>
            <span className="text-xs font-semibold tracking-widest uppercase text-[#E31837] block mb-3">
              02 · Serviços & Valores
            </span>
            <h2 className="font-display-serif text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
              Preço justo. Lâmina afiada.
            </h2>
            <p className="mt-3 text-sm text-slate-400 font-light max-w-xl">
              Cortes tradicionais, barba na lâmina e processos químicos de destaque como luzes e platinado.
            </p>
          </div>

          {/* Interactive filter tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-[#10192C] border border-[#1E2D4A] rounded-lg self-start md:self-auto overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveCategory('all')}
              className={`px-4 py-2 text-xs font-medium tracking-wide uppercase rounded transition-colors whitespace-nowrap shrink-0 ${
                activeCategory === 'all'
                  ? 'bg-[#E31837] text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Todos os Serviços
            </button>
            <button
              onClick={() => setActiveCategory('hair_beard')}
              className={`px-4 py-2 text-xs font-medium tracking-wide uppercase rounded transition-colors whitespace-nowrap shrink-0 ${
                activeCategory === 'hair_beard'
                  ? 'bg-[#E31837] text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Cabelo & Barba
            </button>
            <button
              onClick={() => setActiveCategory('color')}
              className={`px-4 py-2 text-xs font-medium tracking-wide uppercase rounded transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeCategory === 'color'
                  ? 'bg-[#E31837] text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Luzes & Platinar</span>
            </button>
          </div>
        </div>

        {/* Informative notice on first-come, first-served */}
        <div className="mb-12 p-4 rounded-lg bg-[#10192C] border border-[#1E2D4A]/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#E31837]/10 text-[#E31837] rounded">
              <Clock className="w-4 h-4" />
            </div>
            <p className="text-xs sm:text-sm text-slate-300">
              <strong className="text-white font-medium">Ordem de chegada:</strong> Basta chegar na Av. João Selvirio de Souza, 1522. Sem burocracia de agendamento.
            </p>
          </div>
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs font-semibold text-[#E31837] hover:text-white uppercase tracking-wider whitespace-nowrap transition-colors"
          >
            <span>Ver rota no GPS</span>
            <Navigation className="w-3.5 h-3.5" />
          </a>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service, idx) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="group flex flex-col rounded-lg overflow-hidden bg-[#10192C] border border-[#1E2D4A] hover:border-[#E31837]/60 transition-all duration-300 hover:-translate-y-1 shadow-lg"
            >
              {/* Card Image */}
              <div className="relative h-52 overflow-hidden bg-[#080D1A]">
                <img
                  src={service.image}
                  alt={service.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#10192C] via-transparent to-black/30" />

                {/* Badge */}
                <span className="absolute top-3 left-3 text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded bg-[#080D1A]/85 text-slate-200 border border-[#1E2D4A]">
                  {service.badge}
                </span>

                <span className="absolute bottom-3 right-3 text-xs font-mono text-slate-300 bg-black/60 px-2 py-0.5 rounded">
                  {service.duration}
                </span>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-baseline justify-between gap-4 mb-3">
                    <h3 className="font-display-serif text-xl font-bold text-white group-hover:text-[#E31837] transition-colors">
                      {service.title}
                    </h3>
                    <span className="font-condensed text-2xl font-bold text-[#E31837] tabular-nums whitespace-nowrap">
                      {service.price}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed mb-6">
                    {service.description}
                  </p>

                  {/* Bullet list of inclusions */}
                  <ul className="space-y-2 mb-6 border-t border-[#1E2D4A]/50 pt-4">
                    {service.includes.map((inc) => (
                      <li key={inc} className="flex items-center gap-2 text-xs text-slate-400">
                        <Check className="w-3.5 h-3.5 text-[#E31837] shrink-0" />
                        <span>{inc}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Action */}
                <div className="pt-2">
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-semibold uppercase tracking-wider text-slate-200 hover:text-white bg-[#152238] hover:bg-[#E31837] border border-[#1E2D4A] hover:border-[#E31837] rounded transition-colors text-center"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Visitar Barbearia</span>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA bar */}
        <div className="mt-16 text-center">
          <p className="text-xs sm:text-sm text-slate-400 mb-4">
            Dúvida sobre platinar, luzes ou tempo de atendimento?
          </p>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-xs font-bold uppercase tracking-wider text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-all hover:shadow-lg hover:shadow-[#E31837]/20"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Tirar Dúvida no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
};
