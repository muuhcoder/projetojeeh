import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ZoomIn, Eye } from 'lucide-react';

interface GalleryItem {
  id: string;
  title: string;
  category: string;
  image: string;
  aspect: string;
}

export const Gallery: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  const galleryItems: GalleryItem[] = [
    {
      id: 'g1',
      title: 'Degradê & Fade Americano',
      category: 'Corte',
      image: '/src/assets/images/barber_fade_profile_1793127397233.jpg',
      aspect: 'col-span-1 md:col-span-1 lg:col-span-4 h-80',
    },
    {
      id: 'g2',
      title: 'Platinado / Nevou & Luzes',
      category: 'Coloração',
      image: '/src/assets/images/barber_platinado_nevou_1793127871915.jpg',
      aspect: 'col-span-1 md:col-span-2 lg:col-span-8 h-80',
    },
    {
      id: 'g3',
      title: 'Espaço & Clima da Barbearia',
      category: 'Salão',
      image: '/src/assets/images/barbershop_atmosphere_1793127383710.jpg',
      aspect: 'col-span-1 md:col-span-2 lg:col-span-7 h-80',
    },
    {
      id: 'g4',
      title: 'Barba Feita na Lâmina',
      category: 'Barba',
      image: '/src/assets/images/barber_service_beard_1793127382871.jpg',
      aspect: 'col-span-1 md:col-span-1 lg:col-span-5 h-80',
    },
  ];

  return (
    <section id="galeria" className="py-28 md:py-36 bg-[#0B1120] border-t border-[#1E2D4A]/60">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <span className="text-xs font-semibold tracking-widest uppercase text-[#E31837] block mb-3">
            03 · Galeria Visual
          </span>
          <h2 className="font-display-serif text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            A essência de cada detalhe.
          </h2>
          <p className="mt-4 text-base text-slate-300 font-light">
            Trabalhos reais executados com rigor técnico, conforto absoluto e produtos de primeira linha.
          </p>
        </div>

        {/* Gallery Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6">
          {galleryItems.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              onClick={() => setSelectedImage(item)}
              className={`relative rounded-lg overflow-hidden border border-[#1E2D4A] bg-[#080D1A] group cursor-pointer ${item.aspect}`}
            >
              <img
                src={item.image}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover filter brightness-95 group-hover:scale-105 group-hover:brightness-105 transition-all duration-500"
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#080D1A] via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Hover inspect affordance */}
              <div className="absolute top-4 right-4 p-2 bg-[#080D1A]/80 backdrop-blur-sm rounded-full text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <ZoomIn className="w-4 h-4 text-[#E31837]" />
              </div>

              {/* Card Label */}
              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
                <div>
                  <span className="text-[11px] uppercase tracking-wider text-[#E31837] font-semibold block mb-1">
                    {item.category}
                  </span>
                  <h3 className="font-display-serif text-lg font-bold text-white group-hover:text-slate-100 transition-colors">
                    {item.title}
                  </h3>
                </div>
                <span className="hidden sm:inline-flex items-center gap-1 text-xs text-slate-400 group-hover:text-white transition-colors">
                  <Eye className="w-3.5 h-3.5 text-[#E31837]" />
                  <span>Ampliar</span>
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedImage(null)}
            className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8"
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="relative max-w-4xl w-full max-h-[90vh] bg-[#080D1A] border border-[#1E2D4A] rounded-lg overflow-hidden shadow-2xl flex flex-col"
            >
              <div className="flex items-center justify-between p-4 border-b border-[#1E2D4A] bg-[#10192C]">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#E31837] font-bold block">
                    {selectedImage.category}
                  </span>
                  <h4 className="text-sm font-semibold text-white">{selectedImage.title}</h4>
                </div>
                <button
                  onClick={() => setSelectedImage(null)}
                  className="p-1.5 rounded bg-[#152238] text-slate-300 hover:text-white hover:bg-[#E31837] transition-colors"
                  aria-label="Fechar visualização"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="relative flex-1 overflow-hidden bg-black flex items-center justify-center p-2">
                <img
                  src={selectedImage.image}
                  alt={selectedImage.title}
                  referrerPolicy="no-referrer"
                  className="max-h-[70vh] w-auto object-contain rounded"
                />
              </div>

              <div className="p-4 bg-[#10192C] border-t border-[#1E2D4A] text-center">
                <p className="text-xs text-slate-300">
                  Jeeh do Corte · Av. João Selvirio de Souza, 1522, Selvíria - MS · Atendimento por ordem de chegada.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
