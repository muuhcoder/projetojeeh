import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(true);
  const phoneSanitized = '5567981160947';
  const whatsappUrl = `https://wa.me/${phoneSanitized}?text=${encodeURIComponent(
    'Olá! Tenho uma dúvida sobre o atendimento por ordem de chegada na Jeeh do Corte.'
  )}`;

  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-end gap-3 pointer-events-auto">
      {/* Tooltip bubble */}
      {showTooltip && (
        <div className="hidden sm:flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#10192C] border border-[#1E2D4A] shadow-xl text-xs text-slate-200 animate-in fade-in slide-in-from-right-4 duration-300">
          <span>Dúvidas? Fale direto no WhatsApp</span>
          <button
            onClick={() => setShowTooltip(false)}
            aria-label="Fechar aviso"
            className="text-slate-400 hover:text-white p-0.5"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Floating CTA Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Abrir conversa no WhatsApp com Jeeh do Corte"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#E31837] text-white shadow-2xl hover:bg-[#B91029] transition-transform duration-300 hover:scale-110 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#080D1A]"
      >
        {/* Subtle pulsating beacon behind */}
        <span className="absolute -inset-1 rounded-full bg-[#E31837] opacity-40 animate-ping pointer-events-none" />

        <MessageSquare className="w-6 h-6 z-10 transition-transform group-hover:scale-110" />
      </a>
    </div>
  );
};
