import React, { useState, useEffect } from 'react';
import { Menu, X, MessageSquare, MapPin } from 'lucide-react';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Serviços & Valores', href: '#servicos' },
    { label: 'Galeria', href: '#galeria' },
    { label: 'Localização', href: '#contato' },
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const id = href.replace('#', '');
    onNavigate(id);
  };

  const whatsappUrl = 'https://wa.me/5567981160947?text=Ol%C3%A1%21%20Gostaria%20de%20tirar%20uma%20d%C3%BAvida%20sobre%20a%20Jeeh%20do%20Corte.';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#080D1A]/95 backdrop-blur-md border-b border-[#1E2D4A]/80 py-4 shadow-2xl'
          : 'bg-gradient-to-b from-[#080D1A]/90 to-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single element, no noisy subtitles) */}
        <a
          href="#inicio"
          onClick={(e) => handleLinkClick(e, '#inicio')}
          className="group flex items-center gap-3 whitespace-nowrap shrink-0 focus-visible:outline-none"
        >
          <span className="font-condensed text-2xl md:text-3xl font-bold tracking-wider text-white uppercase transition-colors group-hover:text-[#E31837]">
            Jeeh do Corte
          </span>
          <span className="h-2 w-2 rounded-full bg-[#E31837] group-hover:scale-125 transition-transform" />
        </a>

        {/* Zone 2: Navigation Links (Clean typography, no capsules) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium tracking-wide text-slate-300">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={(e) => handleLinkClick(e, link.href)}
              className="relative py-1 whitespace-nowrap shrink-0 hover:text-white transition-colors group"
            >
              {link.label}
              <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-[#E31837] transition-all duration-200 group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Action (1 clean action) */}
        <div className="hidden sm:flex items-center gap-4 shrink-0">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold tracking-wider uppercase text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-all duration-200 hover:shadow-lg hover:shadow-[#E31837]/20 whitespace-nowrap shrink-0"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Falar no WhatsApp</span>
          </a>
        </div>

        {/* Mobile menu trigger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
          className="lg:hidden p-2 text-slate-300 hover:text-white hover:bg-[#152238] rounded transition-colors"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#080D1A]/98 border-b border-[#1E2D4A] px-6 py-6 space-y-4 animate-in fade-in slide-in-from-top-4 duration-200">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleLinkClick(e, link.href)}
                className="text-base font-medium text-slate-300 hover:text-white hover:translate-x-1 transition-all py-1.5"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-4 border-t border-[#1E2D4A]/60 flex flex-col gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-3 text-xs font-bold tracking-wider uppercase text-white bg-[#E31837] hover:bg-[#B91029] rounded text-center transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Dúvidas no WhatsApp</span>
            </a>
            <a
              href="https://www.google.com/maps/search/?api=1&query=Av.+Jo%C3%A3o+Selvirio+de+Souza%2C+1522%2C+Selv%C3%ADria+-+MS"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-medium tracking-wider uppercase text-slate-300 bg-[#152238] hover:bg-[#1E2D4A] rounded text-center transition-colors"
            >
              <MapPin className="w-4 h-4 text-[#E31837]" />
              <span>Ver Localização no Maps</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
