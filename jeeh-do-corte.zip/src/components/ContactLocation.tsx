import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, MessageSquare, Clock, Send, ExternalLink, ShieldCheck, Compass } from 'lucide-react';

export const ContactLocation: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    doubt: '',
  });
  const [error, setError] = useState('');

  const phoneDisplay = '(67) 98116-0947';
  const phoneSanitized = '5567981160947';
  const addressText = 'Av. João Selvirio de Souza, 1522, Selvíria - MS, 79590-000';
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('Av. João Selvirio de Souza, 1522, Selvíria - MS')}`;
  const wazeUrl = `https://waze.com/ul?q=${encodeURIComponent('Av. João Selvirio de Souza, 1522, Selvíria - MS')}`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.doubt.trim()) {
      setError('Por favor, preencha seu nome e a dúvida antes de enviar.');
      return;
    }
    setError('');

    const message = `Olá, meu nome é ${formData.name.trim()} e tenho uma dúvida sobre a Jeeh do Corte: ${formData.doubt.trim()}`;
    const targetUrl = `https://wa.me/${phoneSanitized}?text=${encodeURIComponent(message)}`;
    window.open(targetUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="contato" className="py-28 md:py-36 bg-[#080D1A] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <span className="text-xs font-semibold tracking-widest uppercase text-[#E31837] block mb-3">
            04 · Como Chegar & Atendimento
          </span>
          <h2 className="font-display-serif text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight">
            Venha nos visitar. <br />
            Sem hora marcada.
          </h2>
          <p className="mt-4 text-base text-slate-300 font-light">
            Trabalhamos por ordem de chegada para garantir fluidez e praticidade. Você é sempre bem-vindo.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left Column: Direct Info Cards & GPS Nav */}
          <div className="lg:col-span-6 space-y-8">
            {/* Address Card */}
            <div className="p-8 rounded-lg bg-[#10192C] border border-[#1E2D4A] hover:border-[#E31837]/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-[#E31837]/10 text-[#E31837] rounded-lg shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-display-serif text-xl font-bold text-white">
                    Endereço Oficial
                  </h3>
                  <p className="text-slate-300 text-sm leading-relaxed">
                    {addressText}
                  </p>
                  <p className="text-xs text-slate-400">
                    Ponto de referência: Fácil acesso e estacionamento em frente.
                  </p>

                  <div className="pt-4 flex flex-wrap gap-3">
                    <a
                      href={mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-colors whitespace-nowrap"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Abrir no Google Maps</span>
                      <ExternalLink className="w-3 h-3 ml-0.5 opacity-70" />
                    </a>
                    <a
                      href={wazeUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-slate-200 hover:text-white bg-[#152238] hover:bg-[#1E2D4A] border border-[#1E2D4A] rounded transition-colors whitespace-nowrap"
                    >
                      <span>Abrir no Waze</span>
                      <ExternalLink className="w-3 h-3 opacity-70" />
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Phone & WhatsApp Card */}
            <div className="p-8 rounded-lg bg-[#10192C] border border-[#1E2D4A] hover:border-[#E31837]/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-[#E31837]/10 text-[#E31837] rounded-lg shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div className="space-y-2 flex-1">
                  <h3 className="font-display-serif text-xl font-bold text-white">
                    WhatsApp & Telefone
                  </h3>
                  <p className="font-mono text-xl text-white tracking-wide">
                    {phoneDisplay}
                  </p>
                  <p className="text-xs text-slate-400">
                    Canal direto para tirar dúvidas sobre serviços, produtos ou localização.
                  </p>

                  <div className="pt-3">
                    <a
                      href={`https://wa.me/${phoneSanitized}?text=Ol%C3%A1%21%20Gostaria%20de%20falar%20com%20a%20Jeeh%20do%20Corte.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-colors"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Iniciar Conversa no WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* First-come First-served Trust Card */}
            <div className="p-6 rounded-lg bg-[#0F172A] border border-[#1E2D4A] flex items-start gap-4">
              <ShieldCheck className="w-5 h-5 text-[#E31837] shrink-0 mt-0.5" />
              <div className="text-xs text-slate-300 leading-relaxed">
                <strong className="text-white block font-medium mb-1">
                  Sem agendamento prévio — Como funciona?
                </strong>
                Chegue no salão no seu horário de preferência. Nossa equipe mantém o fluxo contínuo para que você seja atendido o mais rápido possível, sem abrir mão da perfeição na tesoura e na navalha.
              </div>
            </div>
          </div>

          {/* Right Column: Quick Inquiries Form (Redirects to WhatsApp) */}
          <div className="lg:col-span-6">
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="p-8 rounded-lg bg-[#10192C] border border-[#1E2D4A] shadow-xl"
            >
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-[#1E2D4A]">
                <div className="p-2 bg-[#E31837]/10 text-[#E31837] rounded">
                  <MessageSquare className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-display-serif text-lg font-bold text-white">
                    Envie sua Dúvida
                  </h3>
                  <span className="text-xs text-slate-400">
                    Respondemos diretamente no seu WhatsApp
                  </span>
                </div>
              </div>

              {error && (
                <div className="mb-6 p-3 rounded bg-red-950/60 border border-red-800 text-xs text-red-200">
                  {error}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label htmlFor="client-name" className="block text-xs font-medium uppercase tracking-wider text-slate-300 mb-2">
                    Seu Nome *
                  </label>
                  <input
                    id="client-name"
                    type="text"
                    required
                    placeholder="Ex: Carlos Eduardo"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded bg-[#080D1A] border border-[#1E2D4A] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-[#E31837] transition-colors"
                  />
                </div>

                <div>
                  <label htmlFor="client-doubt" className="block text-xs font-medium uppercase tracking-wider text-slate-300 mb-2">
                    Sua Dúvida ou Mensagem *
                  </label>
                  <textarea
                    id="client-doubt"
                    required
                    rows={4}
                    placeholder="Ex: Gostaria de saber sobre platinado, luzes ou como está o movimento hoje..."
                    value={formData.doubt}
                    onChange={(e) => setFormData({ ...formData, doubt: e.target.value })}
                    className="w-full px-4 py-3 rounded bg-[#080D1A] border border-[#1E2D4A] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-[#E31837] transition-colors resize-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-3.5 text-xs font-bold uppercase tracking-wider text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-all hover:shadow-lg hover:shadow-[#E31837]/25"
                  >
                    <Send className="w-4 h-4" />
                    <span>Enviar Dúvida pelo WhatsApp</span>
                  </button>
                  <p className="mt-3 text-[11px] text-slate-500 text-center">
                    Ao clicar, o WhatsApp será aberto com a sua mensagem pronta para envio.
                  </p>
                </div>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};
