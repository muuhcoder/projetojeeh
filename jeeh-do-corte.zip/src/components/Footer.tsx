import React from 'react';
import { MapPin, Phone, MessageSquare, ArrowUp } from 'lucide-react';

interface FooterProps {
  onScrollTo: (id: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onScrollTo }) => {
  const currentYear = new Date().getFullYear();
  const mapsUrl = 'https://www.google.com/maps/search/?api=1&query=Av.+Jo%C3%A3o+Selvirio+de+Souza%2C+1522%2C+Selv%C3%ADria+-+MS';
  const whatsappUrl = 'https://wa.me/5567981160947?text=Ol%C3%A1%21%20Gostaria%20de%20falar%20com%20a%20Jeeh%20do%20Corte.';

  const handleNav = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    onScrollTo(id);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050811] border-t border-[#1E2D4A] pt-16 pb-12 text-slate-400">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-[#1E2D4A]/60">
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-condensed text-2xl font-bold tracking-wider text-white uppercase">
                Jeeh do Corte
              </span>
              <span className="h-1.5 w-1.5 rounded-full bg-[#E31837]" />
            </div>
            <p className="text-xs sm:text-sm text-slate-400 font-light max-w-sm leading-relaxed">
              Tradição, navalha afiada e respeito pelo cliente. Atendimento por ordem de chegada com ambiente climatizado em Selvíria.
            </p>
            <div className="pt-2 text-xs text-slate-500">
              Av. João Selvirio de Souza, 1522 · Selvíria - MS
            </div>
          </div>

          {/* Nav Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white">
              Navegação
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="#inicio"
                  onClick={(e) => handleNav(e, 'inicio')}
                  className="hover:text-white transition-colors"
                >
                  Início
                </a>
              </li>
              <li>
                <a
                  href="#sobre"
                  onClick={(e) => handleNav(e, 'sobre')}
                  className="hover:text-white transition-colors"
                >
                  Sobre Nós & Estrutura
                </a>
              </li>
              <li>
                <a
                  href="#servicos"
                  onClick={(e) => handleNav(e, 'servicos')}
                  className="hover:text-white transition-colors"
                >
                  Serviços & Preços
                </a>
              </li>
              <li>
                <a
                  href="#galeria"
                  onClick={(e) => handleNav(e, 'galeria')}
                  className="hover:text-white transition-colors"
                >
                  Galeria de Estilos
                </a>
              </li>
              <li>
                <a
                  href="#contato"
                  onClick={(e) => handleNav(e, 'contato')}
                  className="hover:text-white transition-colors"
                >
                  Localização & Contato
                </a>
              </li>
            </ul>
          </div>

          {/* Quick Contact & Action */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white">
              Contato Rápido
            </h4>
            <div className="space-y-2 text-xs">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-[#E31837]" />
                <span>(67) 98116-0947 (WhatsApp)</span>
              </a>
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-slate-300 hover:text-white transition-colors"
              >
                <MapPin className="w-3.5 h-3.5 text-[#E31837]" />
                <span>Selvíria, Mato Grosso do Sul</span>
              </a>
            </div>

            <div className="pt-2">
              <span className="text-[11px] text-slate-400 block mb-2">
                Atendimento por ordem de chegada. Sem filas virtuais.
              </span>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-4 py-2 text-[11px] font-bold uppercase tracking-wider text-white bg-[#E31837] hover:bg-[#B91029] rounded transition-colors"
              >
                Falar com a Barbearia
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {currentYear} Jeeh do Corte. Todos os direitos reservados.</p>
          <button
            onClick={scrollToTop}
            aria-label="Voltar ao topo da página"
            className="flex items-center gap-1.5 hover:text-white transition-colors group"
          >
            <span>Voltar ao topo</span>
            <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform text-[#E31837]" />
          </button>
        </div>
      </div>
    </footer>
  );
};
