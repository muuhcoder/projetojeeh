import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Sparkles, Award, Coffee } from 'lucide-react';

export const About: React.FC = () => {
  const atmosphereImage = '/src/assets/images/barbershop_atmosphere_1793127383710.jpg';

  const stats = [
    { value: '15+', label: 'Anos de Tradição', desc: 'Dominando a arte clássica da navalha' },
    { value: '10k+', label: 'Clientes Atendidos', desc: 'Confiança construída corte a corte' },
    { value: '05', label: 'Especialistas', desc: 'Barbeiros dedicados à precisão' },
    { value: '4.9', label: 'Avaliação Média', desc: 'Reconhecimento máximo em Selvíria' },
  ];

  const pillars = [
    {
      icon: Award,
      title: 'Precisão Cirúrgica',
      description: 'Lâminas afiadas, esterilização total e atenção milimétrica a cada acabamento.',
    },
    {
      icon: Coffee,
      title: 'Conforto & Resenha',
      description: 'Café passado na hora, cerveja trincando e poltronas ergonômicas de alto padrão.',
    },
    {
      icon: Sparkles,
      title: 'Produtos Selecionados',
      description: 'Pomadas, óleos e balms de linha profissional para a máxima saúde capilar.',
    },
    {
      icon: ShieldCheck,
      title: 'Atendimento Ágil',
      description: 'Fluxo contínuo por ordem de chegada para respeitar o seu tempo sem filas demoradas.',
    },
  ];

  return (
    <section id="sobre" className="relative py-28 md:py-36 bg-[#0B1120] border-t border-[#1E2D4A]/60">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header with generous negative space */}
        <div className="max-w-3xl mb-16 md:mb-24">
          <span className="text-xs font-semibold tracking-widest uppercase text-[#E31837] block mb-3">
            01 · Tradição & Excelência
          </span>
          <h2 className="font-display-serif text-3xl sm:text-4xl md:text-5xl font-bold text-white tracking-tight leading-tight">
            Mais que um corte. <br />
            Um ritual de confiança e postura.
          </h2>
          <p className="mt-6 text-base md:text-lg text-slate-300 font-light leading-relaxed">
            Na Jeeh do Corte, cada atendimento é conduzido com calma, perícia e respeito ao seu formato de rosto. Unimos o apreço pela barbearia tradicional à pegada urbana dos fades modernos.
          </p>
        </div>

        {/* Asymmetrical Editorial Composition */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center mb-24">
          {/* Left: Atmospheric Image with subtle edge framing */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-6 relative"
          >
            <div className="relative rounded-lg overflow-hidden border border-[#1E2D4A] shadow-2xl bg-[#080D1A]">
              <img
                src={atmosphereImage}
                alt="Ambiente interno sofisticado da barbearia Jeeh do Corte"
                referrerPolicy="no-referrer"
                className="w-full h-[380px] sm:h-[460px] object-cover filter brightness-95 hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#080D1A] via-transparent to-transparent opacity-80" />

              <div className="absolute bottom-6 left-6 right-6">
                <span className="text-[11px] uppercase tracking-wider text-[#E31837] font-semibold block mb-1">
                  Atmosfera Exclusiva
                </span>
                <p className="text-sm font-medium text-slate-200">
                  Espaço pensado para você desligar da correria do dia a dia e renovar sua autoestima.
                </p>
              </div>
            </div>
          </motion.div>

          {/* Right: Pillars & Values */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-8">
            {pillars.map((item, idx) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  className="p-6 rounded-lg bg-[#10192C] border border-[#1E2D4A] hover:border-[#E31837]/50 transition-colors group"
                >
                  <div className="w-10 h-10 rounded bg-[#152238] border border-[#1E2D4A] flex items-center justify-center text-[#E31837] mb-4 group-hover:bg-[#E31837] group-hover:text-white transition-all">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="font-semibold text-white text-base mb-2">{item.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-400 font-light leading-relaxed">
                    {item.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Quantified Rigor: 4-Column Statistics strip with Tabular Numerals */}
        <div className="border-t border-b border-[#1E2D4A] py-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
            {stats.map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="flex flex-col"
              >
                <span className="font-condensed text-4xl sm:text-5xl md:text-6xl font-bold text-white tracking-tight tabular-nums mb-1">
                  {stat.value}
                </span>
                <span className="text-sm font-semibold text-slate-200 mb-1">
                  {stat.label}
                </span>
                <span className="text-xs text-slate-400 font-light">
                  {stat.desc}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
